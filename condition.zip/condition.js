require('dotenv').config({ path: __dirname + './env'});
var KnowledgeObject = require('./sdk/object');
var KnowledgeRelation = require('./sdk/relation');

function getHouseAndPersonForoven(ovenId) {
  console.log('in getHouseAndPersonForoven');
  var oven, house, owner;
  return KnowledgeObject.retrieve(ovenId).then((ovenObj) => {
    oven = ovenObj;
    console.log('oven id', oven.id);
    // Get the house of the oven
    return oven.both('has-as-part');
  }).then((parts) => {
    house = parts[0];
    console.log('House', house.id);
    // Get the owner of the house
    return house.both('ownership');
  }).then((owners) => {
    owner = owners[0];
    console.log('Owner', owner.id);
    return new Promise((res, rej) => {
      res([oven, house, owner]);
    });
  }).catch((err) => {
    console.log('Error: ' + err);
  });
}

function checkType(event, type) {
  var eventType = event[0]['type'];
  if (eventType == type) {
    return true;
  } else {
    return false;
  }
}

function returnContent(value) {
  return {
    headers: {
      'Content-Type': 'text/plain'
    },
    statusCode: 200,
    body: `${value}`
  };
}

function main(event) {
  console.log('in condition main');
  var ovenId = event.results[0]['id'];
  console.log('got oven id as ' + ovenId);
  if (checkType(event.results, 'oven')) {
    return getHouseAndPersonForoven(ovenId).then((objects) => {
      var oven = objects[0];
      var house = objects[1];
      var owner = objects[2];
      // if oven is open and owner isn't at home
      if (oven.attributes.isOpen &&
        (owner.attributes['longitude'] != house.attributes['longitude'] ||
          owner.attributes['latitude'] != house.attributes['latitude'])) {
        console.log("oven is open and owner isn't home - return True");
        return returnContent(true);
      } else {
        console.log("oven is closed or owner is at home - return False");
        return returnContent(false);
      }
    });
  } else {
    console.log("update wasn't on a oven - return False");
    return returnContent(false);
  }  
}
